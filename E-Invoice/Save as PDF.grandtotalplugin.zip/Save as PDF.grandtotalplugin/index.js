/*
	Variables:
	
	document the GrandTotal document formed like the clipboard representation 
	
*/



createFile();


function createFile()
{
	return {};
}




