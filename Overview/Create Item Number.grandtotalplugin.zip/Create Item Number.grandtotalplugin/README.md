# Create Item Numbers from Custom IDs

Allows to create a new item number by concatenating item property IDs and a sequential number based on the existing item numbers (looks for the latest/highest number and increments it). Displays a UI with drop-down menus for selecting the item properties.

Item number example: A_M1_C1_0001
