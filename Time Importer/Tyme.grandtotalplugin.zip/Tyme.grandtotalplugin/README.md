# GrandTotal Invoices

The **Invoice Plugin** which lets you create invoices from billable times in Tyme automatically.

You just have to install their [GrandTotal](https://www.mediaatelier.com) Part. Please refer to the [GrandTotal Plugin Guide](https://www.tyme-app.com/en/grandtotal-plugin) on how to install it.