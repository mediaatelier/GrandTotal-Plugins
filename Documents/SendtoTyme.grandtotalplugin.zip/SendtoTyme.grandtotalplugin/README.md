# GrandTotal Offers

The **Offer Plugin** that enables you to automatically add clients, projects and tasks from a [GrandTotal](https://www.mediaatelier.com) draft invoice to Tyme.

You just have to install their GrandTotal Part. Please refer to the [GrandTotal Plugin Guide](https://www.tyme-app.com/en/grandtotal-plugin) on how to install it.